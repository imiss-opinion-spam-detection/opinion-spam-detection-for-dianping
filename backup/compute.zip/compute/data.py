from datetime import date as date_class
from os import system
from random import randint
from time import time

from matplotlib import pyplot
from networkx import Graph, draw
from pymysql import connect

from compute.classes import User, Product, Review


def get_data(number=0):
    """
     Usage : Get Data from MySQL
     Input : The Data Number You want to get
     OutPut: A List of each record,you should use like this,
            e.g.

            for i in Data:      # i means each record
            [id,name_id,name,contribution,userinforank,review,time,shop,rst1,rst2,rst3]
                for j in i:     # j means each element,t
            class : <"unicode"> except id is <int>
    """
    print("Collecting Data")
    db = connect(host="localhost", user="root", passwd="1111", db="dianping", charset="utf8")
    cur = db.cursor()
    if number == -1:
        cur.execute("SELECT * FROM dianpingcontent")
    else:
        cur.execute("SELECT * FROM dianpingcontent LIMIT " + str(number))
    data = cur.fetchall()
    cur.close()
    db.close()
    print("Data is Ready")
    return data


def unicode_to_datetime(uni_str=""):
    length = len(uni_str)
    if length == 5:
        year = 2016
        month = int(uni_str[0]) * 10 + int(uni_str[1])
        day = int(uni_str[3]) * 10 + int(uni_str[4])
    elif length == 8:  # 15-08-16
        year = 2000 + int(uni_str[0]) * 10 + int(uni_str[1])
        month = int(uni_str[3]) * 10 + int(uni_str[4])
        day = int(uni_str[6]) * 10 + int(uni_str[7])
    else:
        year = randint(2005, 2012)
        month = randint(1, 12)
        day = randint(1, 28)
        print("no date")
    return date_class(year, month, day)


def clear_text(text=""):
    text = text.replace("&nbsp;", " ")
    text = text.replace("&lt;", "<")
    text = text.replace("&gt;", ">")
    text = text.replace("&amp;", "&")
    text = text.replace("&quot;", '"')
    text = text.replace("<br/>", " ")
    return text


def clear_name(text=""):
    text = text.replace(" ", "")
    text = text.replace("\n", "")
    text = text.replace("...", "")
    return text


def rst_to_int(uni_str=""):
    try:
        return int(uni_str[2])
    except ValueError:
        return 2


class DataManager(object):
    def __init__(self, number=0):
        self.data = get_data(number)
        self.count = 0
        self.max_num = len(self.data)
        self.line = self.data[self.count]
        self.id_assign = 0

    def get_next_user(self):
        self.id_assign += 1
        return User(id_number=self.id_assign, name_id=int(self.line[1]), name=self.line[2])

    def get_next_review(self):
        self.id_assign += 1
        return Review(id_number=self.id_assign, text=clear_text(self.line[5]),
                      date=unicode_to_datetime(self.line[6]),
                      rst1=rst_to_int(self.line[9]),
                      rst2=rst_to_int(self.line[10]), rst3=rst_to_int(self.line[11]))

    def get_next_product(self):
        self.id_assign += 1
        return Product(id_number=self.id_assign, name=clear_name(self.line[7]))

    def next_line(self):
        try:
            self.count += 1
            if self.count < self.max_num:
                self.line = self.data[self.count]
        except IndexError:
            print("No More Data")


def build_graph(graph=Graph()):
    print("Opinion Spam Detection System\n" +
          "-----------------------------\n")
    select = int(input("Select : <0. All Data    1. Partial Data>\n"))
    while select != 1 and select != 0:
        print("Wrong Selection")
        select = int(input("Select : <0. All Data    1. Some Data>\n"))
    if select == 1:
        max_data = int(input("Input : <The Number of Data>\n"))
        while max_data <= 0:
            print("The Data Number Should > 0")
        data_manager = DataManager(max_data)
    else:
        data_manager = DataManager(-1)
        max_data = len(data_manager.data)
    start_time = time()
    print("Get " + str(max_data) + " Data")
    print("Building Graph")
    user_dict = dict()
    product_dict = dict()
    for i in range(max_data):
        user = data_manager.get_next_user()
        review = data_manager.get_next_review()
        product = data_manager.get_next_product()
        if (user.__class__, user.name, user.name_id) in user_dict:
            user = user_dict[(user.__class__, user.name, user.name_id)]
        else:
            user_dict[(user.__class__, user.name, user.name_id)] = user
        if (product.__class__, product.name) in product_dict:
            product = product_dict[(product.__class__, product.name)]
        else:
            product_dict[(product.__class__, product.name)] = product
        data_manager.next_line()
        # In NetworkX, the implement of node is dict.
        # The implement of dict is hash.
        # In list, two same-data but diff-address objects are the same.
        # In dict, two same-data but diff-address objects are different unless __hash__() is re-defined
        graph.add_node(review)
        graph.add_node(user)
        graph.add_node(product)
        graph.add_edge(user, review)
        graph.add_edge(review, product)
    print("Graph is Ready")
    print("Time Spent on Building Graph : %d" % (time() - start_time))


def show_result(graph=Graph(), mode="cmd"):
    if mode == "cmd":
        usage = "Opinion Spam Detection System\n" + \
                "-----------------------------\n" + \
                "Command : \n" + \
                "    all : show all info of all nodes\n" + \
                "    select : input an id and get a result\n" + \
                "    about : show more info about selected node\n" + \
                "    sort : sort all the nodes\n" + \
                "    usage : print usage\n" + \
                "    clear : clear your terminal\n" + \
                "    quit : exit this program\n"
        print(usage)
        cur_node = None
        graph_list = [node for node in graph.nodes()]
        graph_dict = dict([(node.id_number, node) for node in graph.nodes()])
        while True:
            command = str(input(">>> "))

            if command == "quit":
                print("Bye")
                break

            elif command == "select":
                try:
                    id_number = int(input("... input id "))
                    result = None
                    if id_number in graph_dict:
                        result = graph_dict[id_number]
                        print(result)
                        cur_node = result
                    else:
                        print("This id do not exist")
                except ValueError:
                    print("Command Error")

            elif command == "about":
                if cur_node is None:
                    print("You should search a node and then show its more info")
                else:
                    print("current node:")
                    print(cur_node)
                    print(str(len(graph.neighbors(cur_node))) + " neighbor(s)")
                    for neighbor in graph.neighbors(cur_node):
                        print(neighbor)

            elif command == "usage":
                print(usage)
            elif command == "clear":
                system("reset")
                print(usage)
            elif command == "sort":
                select = int(input("... mode : 0->greater 1->less "))
                while select != 0 and select != 1:
                    select = int(input("... mode : 0->greater 1->less "))
                graph_list.sort(key=lambda node: node.belief[select])

            elif command == "all":
                for node in graph_list:
                    print(node)

            else:
                print("This command do not exist")

    elif mode == "simple":
        for node in graph.nodes():
            print(node)


    elif mode == "ui":
        pass
    elif mode == "net":
        pass
    elif mode == "no":
        print("Show Nothing")
    else:
        raise ValueError("No such a mode called" + mode)


def show_graph(graph=Graph()):
    draw(graph)
    pyplot.show("graph.png")
    pyplot.show()


def say_finish(times=1):
    def say(voice="", content=""):
        system("say -v " + voice + " " + content)

    print("This program is finish")
    voice_list = ["Daniel", "Samantha"]
    for i in range(times):
        say(voice_list[randint(0, len(voice_list) - 1)], "This program is finish")


if __name__ == "__main__":
    say_finish()
