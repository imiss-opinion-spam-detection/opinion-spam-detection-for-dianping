# from time import time
#
# from networkx import Graph
#
# from compute.data import build_graph
#
# if __name__ == "__main__":
#     start_time = time()
#     graph = Graph()
#     build_graph(graph)
#     # count = 0
#     # for node in graph.nodes():
#     #     if node.__class__ == Review().__class__:
#     #         for product in graph.neighbors(node):
#     #             if product.__class__ == Product().__class__:
#     #                 product.printf()
#     #         print("------")
#     # count+=1
#     # print(count)
#     # set_prior(graph)
#     # lbp(graph)
#     # show_result(graph)
#     print("Time : %d" % (time() - start_time))
